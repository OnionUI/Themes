# AnalogPhosphor
A theme for Onion on the Miyoo Mini (+)



This is a very early work in progress. As such there are some images from other themes currently as I was using them as templates to start off of. I'll be updating them eventually and I'll add it to the [Onion Theme Repo when it's done](https://github.com/OnionUI/Themes/blob/main/README.md). :D

## AnalogPhosphor
![](preview.png)

## AnalogPhosphor OG
![](previewOG.png)
