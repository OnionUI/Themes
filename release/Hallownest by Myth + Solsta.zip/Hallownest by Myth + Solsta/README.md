- Author: Myth and Solsta
- Name: Hallownest
- Info: Inspired by Hollow Night (Team Cherry)
- Credits:
  - NPCs, backgrounds and
decorations/frames images are from [Hollow Knight Wiki](https://hollowknight.fandom.com/)
  - Selection sound it's the "Dash" from Hollow Knight
  - For the theme structure we took inspiration from `CyberOnion` and `GameMaster`
