PocketFighterMini by nGlory (find me on discord if there are recommendations/requests)

2024.04.26

- my first theme
- took too long and had to pre-release it because my body is sore from work & i need a break
- missing settings icons
- missing extras like saving & screen off among other things
- majority of the theme is functional
- using stock console icons
- created font ripped from an image just for the theme
- sprites from ripped images found online
- sounds ripped from game found online
- logotweak zip file to add boot screen through logotweak app

- i WILL finish the theme a week or so after upload, please bare with me



2024.04.27

- had energy today so i finished all the leftover edits
- changed some logos around
- changed game icon backgrounds because the transparency leaves undesired effect
- aemiii91 helped me figure out some elements, like gs bar & how it works
- added icons for settings
- saving screen and off screen are implemented

2024.05.09

- softened the change.wav sound because someone on discord said it might be too harsh
- enlarged akuma sprite in chargingstate animation for better visual effect
- changed icon bg to gems & select icons
- iconset is from yoshi-kun's dot pack