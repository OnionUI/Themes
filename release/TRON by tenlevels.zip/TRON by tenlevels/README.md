# TRON by tenlevels

TRON Theme: Miyoo Mini theme inspired by the movie Tron Legacy.


## Special Thanks

A very special thank you to Aemiii91 for the helpful tips, tricks and creative input.

Charging animation and icon pack by Aemii91.


## Disclaimer

This theme is just fan art to be enjoyed.
