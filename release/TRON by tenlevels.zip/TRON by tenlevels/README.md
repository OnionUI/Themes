# TRON Theme

TRON Theme: Miyoo Mini theme inspired by the movie Tron Legacy.

## Additional Credit - Special Thanks

A very special thank you to Aemiii91 for the helpful tips, tricks and creative input. The charging graphic was created and animated by Aemii91.

## Disclaimer
This theme is just fan art to be enjoyed.