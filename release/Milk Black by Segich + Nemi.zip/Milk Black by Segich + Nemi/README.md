----------------------
 Milk White by Segich
----------------------
<div align="center"><img align="center" alt="Miyoo Mini Milk Logo" src="https://raw.githubusercontent.com/SergeiBabko/miyoo-mini-milk-theme/main/assets/logo.png"></div>

**Add a cozy and nostalgic touch to your Miyoo Mini retro handheld system with the Miyoo Mini Milk theme. Featuring warm white and soft orange colors, and cute illustrations, this theme is perfect for fans of retro gaming who want to enjoy a blast from the past.**

<p align="center">
    <a href="https://github.com/SergeiBabko/miyoo-mini-milk-theme/releases/latest" target="_blank"><img alt="Latest Release" src="https://raw.githubusercontent.com/SergeiBabko/miyoo-mini-milk-theme/main/assets/download_latest.png" height="50px"></a>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="https://ko-fi.com/segich" target="_blank"><img alt="Support" src="https://raw.githubusercontent.com/SergeiBabko/miyoo-mini-milk-theme/main/assets/kofi_support.png" height="50px"></a>
</p>

-------
 LINKS
-------
**Original source: https://github.com/SergeiBabko/miyoo-mini-milk-theme**  
**Support: https://ko-fi.com/segich**

---------
 CREDITS
---------
Icons by: Segich, Icons8, Flaticon, Onion, Dreambrace, Miyoo
