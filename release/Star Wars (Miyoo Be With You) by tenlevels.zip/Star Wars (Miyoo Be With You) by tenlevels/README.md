# `Star Wars (Miyoo Be With You)` *by* `tenlevels`

Star Wars inspired theme for May 4th.


## Credits

**Icons:** By [Icons8](https://icons8.com/) - IOS 17 Filled, Windows 11 Outline,Windows 11 filled

**Console icons:** [Silhouette by Dreambrace] (https://onionui.github.io/iconpack_preview.html#Silhouette%20White%20by%20Dreambrace)

**Star Wars Font** Starjedi.ttf by Boba Fonts

**Background Music** Main Title · John Williams · London Symphony Orchestra