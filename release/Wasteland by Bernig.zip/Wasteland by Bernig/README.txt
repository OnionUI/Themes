Credits

https://icons8.com/icon/QyZp4Pat02yK/pixel-star
https://www.freepik.com/icon/heart_626575#position=24&page=1&term=pixel+art&fromView=search
https://www.freepik.com/icon/robot_8254111#position=87&page=1&term=pixel+art&fromView=search
https://www.freepik.com/icon/goal_1006984#position=33
https://www.freepik.com/icon/sunglasses_7159350#position=36&page=2&term=pixel+art&fromView=search
https://www.freepik.com/icon/game-boy_934372#position=72&page=1&term=pixel+art+controller&fromView=search
https://www.freepik.com/icon/app-drawer_10025537#position=43&page=2&term=pixel+apps&fromView=search
https://www.freepik.com/icon/clock_465229#position=1&page=1&term=pixel+art+clock&fromView=search
https://www.flaticon.com/free-icons/lock
https://www.flaticon.com/free-icons/ftp
https://www.flaticon.com/free-icons/symbol
https://www.flaticon.com/free-icons/evolution
https://www.flaticon.com/free-icons/compress
https://www.flaticon.com/free-icons/internet
https://www.flaticon.com/free-icons/joystick

icons from "Silhouette Black by Dreambrace"

All other icons derived from stock Miyoo Mini icons.
