# `Material` *by* `tenlevels`

Minimal theme with hidden icons exposed with colored circles.


## Credits

**Icons:** By [Icons8](https://icons8.com/) - Plumpy, IOS 17 Filled, IOS17 Glyph and Material Rounded

**Console icons:** From [Art Book Next by anthonycaccese] (https://github.com/anthonycaccese)

**Colors** Purple from OnionOS and Green from Discord


## Special Thanks

Thank you Aemiii91 for always helping me with my themes, OnionOS and being such an inspiration in the community.