# `Mucha Miyoo` *by* `LamiaLazuli`

*Vintage Art Noveau theme inspired by Mucha; folder icons not drawn by me*


## Credits

**Icons:** Custom made icons by 'UnBurn' in the 'Notebook Kawaii' theme, edited by me
https://github.com/OnionUI/Themes/raw/main/release/Notebook%20Kawaii%20by%20UnBurn.zip

**Font:** SymphonyoftheNightfont from 'CastlevaniaSOTN' by 'RoeTaKa'  
https://github.com/OnionUI/Themes/raw/main/release/CastlevaniaSOTN%20by%20RoeTaKa.zip

**Sound:** taken from'CastlevaniaSOTN' by 'RoeTaKa'

**Name:** reddit user - L0lil0l0 (super cute name!)


To reiterate, I did not draw the console icons. They are by the famous artist Alphonse Mucha. The console icons are by 'UnBurn', edited to to fit the theme more (edits= color changes, remove faces from consoles). The font and sound is found in the 'CastlevaniaSOTN' theme by 'RoeTaKa', not original to RoeTaKa, but rather the Castlevania game, as stated by them. Thank you reddit user L0lil0l0 for the cute name!