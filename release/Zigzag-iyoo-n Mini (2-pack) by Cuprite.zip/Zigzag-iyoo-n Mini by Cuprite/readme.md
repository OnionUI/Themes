# Zigzag-iyoo-n Mini

## Alternate Parts

There's a folder in "extra" called "Alternate Parts." It's exactly what it sounds
like: Alternate files for if you want your version of the theme to look a bit
different from the default look. I mostly included it due to my own indecisiveness,
but I thought it'd be cool to include it as a little bonus. :)

## Thank you

If you downloaded this, I really hope you enjoy it. I'm happy with the result.

- Cuprite