Counter Strike 1.6 Theme for OnionOS by 0x3.
--------------------------------------------
https://github.com/trashplusplus
-------------------------------------------