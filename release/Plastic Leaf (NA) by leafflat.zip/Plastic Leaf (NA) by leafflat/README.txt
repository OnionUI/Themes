*************************
HOW TO INSTALL THIS THEME
*************************

1. Copy the theme folder into the "Themes" folder of your SdCard
2. Turn on your Miyoo Mini and find the theme in the settings section
3. Enjoy your new theme !



******************
Credits
******************

Music by Karl Casey @ White Bat Audio



******************
Questions? Comments?
******************

Send me an email at plasticleaf@outlook.com