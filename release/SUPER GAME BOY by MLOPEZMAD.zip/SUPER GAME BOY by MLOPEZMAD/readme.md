# Super Game Boy by mlopezmad

Inspired by the Lilla theme by Evolve.

## Important!

In this theme you can't use the recent and expert tabs, otherwise you will see that the screens are displaced. 
Make sure you have them disabled in: **Apps** -> **Tweaks** -> **Appearance**.


## Credits

- Main page icons by users from flaticon.com:
  - [Electricity icons](https://www.flaticon.com/free-icons/electricity) created by srip - Flaticon
  - [Maze icons](https://www.flaticon.com/free-icons/maze) created by Becris - Flaticon
  - [Grid icons](https://www.flaticon.com/free-icons/grid) created by Kiranshastry - Flaticon
  - [Settings icons](https://www.flaticon.com/free-icons/settings) created by Freepik - Flaticon
  - [History icons](https://www.flaticon.com/free-icons/history) created by joalfa - Flaticon
  - [Nintendo icons](https://www.flaticon.com/free-icons/nintendo) created by Freepik - Flaticon
  - [Star icons](https://www.flaticon.com/free-icons/star) created by Pixel perfect - Flaticon

- Screen backgrounds by mlopezmad

- Icons Anbernic Blues Colored Type I by RubberDuckNoises adapted to the theme by mlopezmad

- Images menu and select game by mlopezmad

- Icons by [Icons8](https://icons8.com)

- All other icons derived from stock Miyoo Mini icons
