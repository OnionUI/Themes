I was inspired by the theme of System 9 by injekim, but I wanted to make it based on the WIN 98 
I used to sit in as a child, just when there was an era of consoles.


W95FA is a modern re-creation of old Microsoft font used in Windows 95.

Includes both .otf and webfonts (.woff2 and .woff). You can see the font in action as webfont in a Windows95 theme here: https://w95theme.com

Free for both personal and commercial use, licensed under SIL OpenFont license.