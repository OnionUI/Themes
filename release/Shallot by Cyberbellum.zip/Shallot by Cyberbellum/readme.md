# `Shallot` *by* `Cyberbellum`

*Minimalist theme, inspired by Aemiii91's Analogue theme*

## Credits

Custom made icons by Aemiii91:
`cps3`, `gw`, `pico`, `poke`, `ports`, `satella`, `scummvm`, `search`, `sufami`, and `tic`.

**Console icons:** Analogue openFPGA Platform Art Set by spiritualized1997  
https://github.com/spiritualized1997/openFPGA-Platform-Art-Set
