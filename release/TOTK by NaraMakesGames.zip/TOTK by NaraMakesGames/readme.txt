The Legend of Zelda: Tears of the Kingdom Theme by Nara Makes Games
instagram.com/naramakesgames

I used the Silky theme by DiMo as my reference point. So a lot of what I have in mine is just recolored versions of their work.