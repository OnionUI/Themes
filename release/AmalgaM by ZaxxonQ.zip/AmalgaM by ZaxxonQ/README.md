# `AmalgaM` *by* `ZaxxonQ`

A simple amalgam of previous themes


## Credits

AmalgaM Onion OS theme for the Miyoo Mini by ZaxxonQ

The AmalgaM theme includes original edits along with elements from the following Miyoo Mini Onion OS themes and users:

M by tenlevels  
Analogue by Aemiii91  
Blueprint Variations by Aemiii91 + r3b0rn  
Concise Black White by mtaras  
GBOnion Dark by Kitsuvi + andresandiah  
less by junk  
mini.os by nationalsoup  
minimO by AccomplishedSir  
Onyan by PixelShift  
PSPmini by MarsTaco  

I highly suggest checking their full themes out at:  
https://github.com/OnionUI/Themes


## Special Thanks

If I have missed anyone, please accept my apologies and let me know: ZaxxonQ [at] ZaxxonQ.com
