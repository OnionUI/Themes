# `NEON.ion` *by* `tenlevels`

NEON theme inspired by Essenger


## Credits


**MAIN ICONS - SETTING ICONS:** source - Noun Project and originals by me

**APP ICONS:** Icons8

**CONSOLE ICONS:** CyberOnion pack by Aemiii91 - colors adjusted by Aemiii91 and myself with glow effect

**BACKGROUND MUSIC** music by Essenger



## Special Thanks

Thank you Aemiii91 for always helping me with my themes, OnionOS and being such an inspiration in the community.