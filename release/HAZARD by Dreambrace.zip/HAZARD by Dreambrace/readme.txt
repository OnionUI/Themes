Most icons derived from icons available at:

https://www.flaticon.com

&

https://icons8.com