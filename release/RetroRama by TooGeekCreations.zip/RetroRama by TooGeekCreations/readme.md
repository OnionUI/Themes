# RetroRama by TooGeekCreations

RetroRama theme for Miyoo Mini Plus created by:  
*Gyorgy Banyar* aka. [TooGeekCreations](https://www.facebook.com/profile.php?id=100063379200331)

Inspired by the RetroRama theme for Retropie or LaunchBox frontend made by:  
*Filipe Bello* aka. [Phill's Doodles](https://www.instagram.com/_phills_doodles_/)  

Comic book style drawings from:  
*Filipe Bello* aka. [Phill's Doodles](https://www.instagram.com/_phills_doodles_/)  
(modifications made by: TooGeekCreations)

I got permission to use Phill's Doodles graphics for this theme and release it for the Miyoo Mini Plus.
