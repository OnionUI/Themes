Credits

Inspired by the Lilla theme by Evolve.
onionos icon by Hakchi Pixel Art by faustbear.

Main page icons by users from flaticon.com:
https://www.flaticon.com/free-icons/electricity - Electricity icons created by srip - Flaticon
https://www.flaticon.com/free-icons/maze - Maze icons created by Becris - Flaticon
https://www.flaticon.com/free-icons/gridGrid icons created by Kiranshastry - Flaticon
https://www.flaticon.com/free-icons/settings - Settings icons created by Freepik - Flaticon
https://www.flaticon.com/free-icons/history - History icons created by joalfa - Flaticon
https://www.flaticon.com/free-icons/nintendo - Nintendo icons created by Freepik - Flaticon
https://www.flaticon.com/free-icons/star - Star icons created by Pixel perfect - Flaticon

screen backgrounds 

https://github.com/nithou/minimal-onionOS

Icons 

Hakchi Pixel Art by faustbear

All other icons derived from stock Miyoo Mini icons.