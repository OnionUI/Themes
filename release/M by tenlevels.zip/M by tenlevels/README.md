# `M` *by* `tenlevels`

Minimal theme inspired by Miyoo logo


## Credits

**M:** From Miyoo logo

**Fonts:** Gravity Regular and Gravity Light by Vincenzo Vuono

**Icons:** By [Icons8](https://icons8.com/) - Windows 11 Outline and Those Icons Lineal

**Console icons:** Default OnionOS (libretro systematic)

**Charging animation:** By Dreambrace


## Special Thanks

Thank you Aemiii91 for always helping me with my themes, OnionOS and being such an inspiration in the community.