All icons remade from stock Miyoo Mini icons.

Battery percentage already aligned, can be enabled in Tweaks -> Appearance -> Theme overrides