# TechDweeb Orange Stuff

> Updated for the latest version of Onion OS (4.3.0)

![](./preview.png)


## TechDweeb ONION OS Theme FLAVOR PACK!
*March 13, 2024*

Everyone knows Orange is the best flavor, but sometimes we get bored of the same thing day after day forever and ever until we're buried in the cold cold ground... 

So why not spice up your slow journey to the grave with some squishy new TechDweeb themes for your Miyoo Mini?!? 

### [Get it here!](https://www.patreon.com/posts/techdweeb-onion-100316832)

[![](./Advert.jpg)](https://www.patreon.com/posts/techdweeb-onion-100316832)
