# `Analogue` *by* `Aemiii91`

*Minimalist theme inspired by Analogue OS*

Custom made icons by me:  
`cps3`, `gw`, `pico`, `poke`, `ports`, `satella`, `scummvm`, `search`, `sufami`, and `tic`.

## Credits

**Font:** Analogue OS font by AbFarid  
https://github.com/AbFarid/analogue-os-font

**Console icons:** Analogue openFPGA Platform Art Set by spiritualized1997  
https://github.com/spiritualized1997/openFPGA-Platform-Art-Set
