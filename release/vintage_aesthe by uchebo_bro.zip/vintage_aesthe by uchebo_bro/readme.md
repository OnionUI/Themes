# 'vintage_aesthe' by uchebo bro

*inspired windows98, retro japan game, vapor wave*

font : galmury

boot screen source : aestaste/,https://aestaste-it.tumblr.com/post/140754476898

main girl : asadrococo  https://www.pinterest.co.kr/asadrococo/

main background art :  unknown artist

app icon : windows 98, revamped by me

setting icon : pokemon red version

game icon source : game console icon by jeltron (I just adjusted the color tone)