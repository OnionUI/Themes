Here's some steps to ensure the theme works correctly.


1. Copy the "Zenburn by duckbeets" folder to the "Themes" folder.
2. Copy the Contents "tmp_update files" to your ".tmp_update" folder


Optional:

1. Install "3Easy LogoTweak" from here: https://github.com/schmurtzm/Miyoo-Mini-easy-logotweak"
2. Install the "Zenburn by duckbeets" boot screen


Flashing your device to change the boot screen is apparently risky, so do this at your own risk.

If any of the theme files need updating in future, I'll try, but I have very limited time. You can contact me on reddit, the username: duckbeets
