# CastlevaniaSOTN by RoeTaKa

Edited from the Genshin-Thunder theme for the Miyoo Mini.

All artwork is from Castlevania or promotional material for Castlevania (eg: the frames/background art)