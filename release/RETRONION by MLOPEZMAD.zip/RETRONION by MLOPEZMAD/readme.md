# RETRONION by mlopezmad


## Important!

In this theme you can't use the recent and expert tabs, otherwise you will see that the screens are displaced. 
Make sure you have them disabled in: **Apps** -> **Tweaks** -> **Appearance**.


## Credits

- Screen backgrounds by mlopezmad

- Icons Hakchi Pixel Art by faustbear

- Images menu and select game by mlopezmad

- All other icons derived from stock Miyoo Mini icons

## Thanks

Thanks to JulenSR for helping me find a menu letter for this theme. My adventure companion in this retro world, so special mention for you.

Thanks to the entire Onion team, especially aemiii, always helping with the doubts I have had on the subject.

