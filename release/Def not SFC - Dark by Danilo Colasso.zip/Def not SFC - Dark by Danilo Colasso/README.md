# Def not SFC - Dark
A Dark SFC theme for Onion OS

![Preview](preview.png)

<sup>Special thanks to Alpatov Danila for some arts</sup>

Made with ♡ by [Danilo Colasso](https://github.com/danilocolasso)