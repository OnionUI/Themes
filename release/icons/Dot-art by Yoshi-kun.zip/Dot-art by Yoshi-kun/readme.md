# Dot-art by Yoshi-kun

Source: http://yspixel.jpn.org/icon/game/

Ported by Cindy Nemi and Aemiii91
