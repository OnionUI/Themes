These icons are meant to be used with the "bg-game-item-f.png" included in the "skin" folder. Move this to the "skin" folder of the theme of your choice.

You also need to edit your theme's config.json and set grid -> font to /mnt/SDCARD/miyoo/app/AdobeBlank.ttc. This will hide the console names, as well as the main menu icon labels. Make sure you have AdobeBlank.ttc at this location.

It would be a good idea to backup your theme before making these changes in case you would like to revert to the original.