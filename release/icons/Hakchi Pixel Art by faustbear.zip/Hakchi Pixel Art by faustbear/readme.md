# Hakchi Pixel Art by faustbear

*Ported by Aemiii91*

Source: https://www.reddit.com/r/miniSNESmods/comments/995ylx/additional_pixel_art_icon_pack_22/

Custom icons by Aemiii91: `pico`, `ports`, `search`, `supervision`, `tic`, `vdp`

Custom icons by Smushi: `poke`, `neocd`, `gbc` + alts (recolor), `cps2` + `cps3` (recolor)
