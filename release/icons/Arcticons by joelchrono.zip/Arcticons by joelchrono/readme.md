## Arcticons Icon Pack for OnionOS

This is an icon pack made with the same style of the original Arcticons project made for Android devices.

![](https://img.itch.zone/aW1hZ2UvMjcyNDM3MC8xNjI0Njk5My5wbmc=/original/yWVI2G.png)

You can download Arcticons for your phone [here](https://github.com/Arcticons-Team/Arcticons).

You can also check the source of these icons [here](https://github.com/Arcticons-Team/Arcticons-Miyoo).

Also feel free to check [my website](https://joelchrono.xyz/).