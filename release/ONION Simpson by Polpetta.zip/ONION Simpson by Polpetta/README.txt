
--------------------------------------------
 ONION SIMPSON THEME  Instructions & Credits
--------------------------------------------

Based on Hanessh4 ONION PS theme, thanks to him :)

General:
--------

- Each theme color variant works independently. You can use one of them, or all.
- Theme includes image for easylogotweak: skin/extra/image1.jpg


PS MOD:
-------

- The theme can be modified, that onscreen buttons match physical face buttons on your Miyoo mini if PS button mod is used
- ABXY buttons is used as default

Installation of mod:
1. Open "PS MOD" folder inside /skin/_Theme MODS
2. Copy all files and folders
3. Go back to skin folder
4. Paste and replace all files (and folders)

Warning for MAC OSX users:
- Do not paste and replace folder "extra" - this would remove all other files in that folder
- Instead, first copy and replace files from skin folder, than copy and replace files from extra folder

