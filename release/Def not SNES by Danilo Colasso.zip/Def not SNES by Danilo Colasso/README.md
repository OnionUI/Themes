# Def not SNES
A SNES theme for Onion OS

![Preview](preview.png)

<sup>Special thanks to Alpatov Danila for some arts</sup>

Made with ♡ by [Danilo Colasso](https://github.com/danilocolasso)