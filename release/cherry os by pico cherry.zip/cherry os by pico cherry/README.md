# `cherry os` by `pico cherry`
retro/pixel art theme inspired by [picocherry.com](https://picocherry.com) colors.

## Credits
**Console icons:** Analogue openFPGA Platform Art Set by `spiritualized1997`   
[https://github.com/spiritualized1997/openFPGA-Platform-Art-Set](https://github.com/spiritualized1997/openFPGA-Platform-Art-Set)