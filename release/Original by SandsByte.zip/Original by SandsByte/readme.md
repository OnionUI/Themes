Original by SandsByte for Onion 4.2 (https://github.com/OnionUI/Onion)

Created for the Onion and Miyoo community in June, 2023

Thank you for using!

**Want to use my themes in your project?**
- You are free to use and mix for personal and private use
- Please contact me at 07.sands.byte@ icloud(dot)com to mix and share

**GOALS**
- Simple and default feel
- Easy on the eyes
- Compatible with icon packs

**ATTRIBUTIONS**
- Icons provided by https://icons8.com/ or created personally
- Sound by https://freesound.org/s/288912/

**THANK YOU**
- Evolve, TheDewd, and Aemiii91 for their great work, care, and inspiration